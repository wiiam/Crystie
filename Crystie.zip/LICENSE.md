# License for Discord-MusicBot

* The credits should not be changed.
* The bot-code should be used for **private hosting** and **personal usage** only.
* Using the code for public usage is **not allowed**.

> **Note:** if you are found to be violating any of the above stated rule you might be asked to takedown your bot, happy listening!! Incase of any doubts in the license contact owner.
